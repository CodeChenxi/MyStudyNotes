package com.atguigu.demo;

public class Person {

    public String getName() {
        return "tom";
    }

}
