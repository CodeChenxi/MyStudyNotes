package com.atguigu.maven;

public class Message {

    public String getMessage() {
        return "hello message";
    }

}
