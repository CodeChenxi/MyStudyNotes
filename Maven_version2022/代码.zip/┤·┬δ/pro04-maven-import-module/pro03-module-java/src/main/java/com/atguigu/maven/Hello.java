package com.atguigu.maven;

public class Hello {

    public void showMessage() {
        System.out.println("Hello maven!I am in idea now!");
    }

    public static void main(String[] args) {
        System.out.println("hello import module ...");
    }

}
