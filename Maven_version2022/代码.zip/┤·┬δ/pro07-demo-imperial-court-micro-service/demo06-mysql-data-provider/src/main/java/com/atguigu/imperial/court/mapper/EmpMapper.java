package com.atguigu.imperial.court.mapper;

import com.atguigu.imperial.court.entity.Emp;
import tk.mybatis.mapper.common.Mapper;

public interface EmpMapper extends Mapper<Emp> {
}
