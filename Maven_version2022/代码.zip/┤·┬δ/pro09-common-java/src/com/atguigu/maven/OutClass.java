package com.atguigu.maven;

public class OutClass {

    public String getName() {
        return "tom from outer class";
    }

}
